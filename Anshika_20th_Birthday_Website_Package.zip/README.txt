HOW TO USE

1. Put your couple photos into assets/images/
   Rename them photo1.jpg, photo2.jpg, photo3.jpg etc.

2. Put your song into assets/music/
   Rename it song.mp3

3. Upload the entire folder to Netlify or Vercel.
