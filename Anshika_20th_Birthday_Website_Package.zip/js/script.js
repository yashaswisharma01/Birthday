
const reasons=[
"Your smile","Your eyes","Your voice","Your kindness","Your honesty",
"Your care","Your support","Your patience","Your laughter","Your innocence",
"Your strength","Your intelligence","Your positivity","Your hugs","Your love",
"Your understanding","Our memories","The peace you bring","Your beautiful heart","Because you're simply YOU ❤️"
];
let c=document.getElementById("reasons");
reasons.forEach((r,i)=>{
 let d=document.createElement("div");
 d.className="reason";
 d.innerHTML=(i+1)+". "+r;
 c.appendChild(d);
});
for(let i=0;i<50;i++){
 let h=document.createElement("div");
 h.className="heart";
 h.innerHTML="❤";
 h.style.left=Math.random()*100+"vw";
 h.style.animationDuration=(5+Math.random()*6)+"s";
 h.style.fontSize=(12+Math.random()*20)+"px";
 document.body.appendChild(h);
}
